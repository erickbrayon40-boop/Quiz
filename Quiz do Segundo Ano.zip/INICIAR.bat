@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Falha ao instalar as dependencias. Verifique se Python esta instalado.
  pause
  exit /b 1
)
echo.
echo Abra http://localhost:5000 no seu navegador.
echo Mantenha esta janela aberta enquanto estiver jogando.
echo.
python app.py
pause
